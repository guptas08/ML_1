import pickle
import pandas as pd

df=pd.read_csv("insurance.csv")

def fit_smoking(smoker,bmi):
    if smoker=="yes" and bmi>30:
        return "Fat_Smoker"
    elif smoker=="yes" and bmi<=30:
        return "Fit_Smoker"
    elif smoker=="no" and bmi>30:
        return "Fat"
    else:
        return "Fit"
df["Smoking_Fit"]=df[["smoker","bmi"]].\
            apply(lambda x: fit_smoking(x["smoker"],x["bmi"]),axis=1)

X=df[['age', 'sex', 'bmi', 'children', 'region', 'Smoking_Fit']].copy()
#y=df[ 'charges'].copy()

X.sex=X.sex.map(lambda x: 1 if x=="male" else 0)
X=X.join(pd.get_dummies(X.region)).drop(['region'],axis=1)
X=X.join(pd.get_dummies(X.Smoking_Fit)).drop(['Smoking_Fit'],axis=1)


with open('model_v1.pickle', 'rb') as f:
    # The protocol version used is detected automatically, so we do not
    # have to specify it.
    lr = pickle.load(f)

print(lr.predict(X[:5]))
